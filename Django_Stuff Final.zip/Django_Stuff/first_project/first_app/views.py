from django.shortcuts import render, render_to_response
from django.http import HttpResponse
from .models import movies
from django.db import connection
from django.core.exceptions import *
import os

#adding consol project
import json
import re
import requests
import warnings
import numpy as np
import pandas as pd
import mysql.connector
import urllib.request
from scipy import stats
import seaborn as sns
from currency_converter import CurrencyConverter
from matplotlib import pyplot as plt
from bs4 import BeautifulSoup
import urllib.request
warnings.filterwarnings('ignore')
sns.set(style="darkgrid", color_codes=True)

#DataBase connection
def DatabaseConnection(user, passwd, database):
    try:
        mydb = mysql.connector.connect(host='localhost',
                                       user=user,
                                       password=passwd,
                                       database=database,auth_plugin='mysql_native_password')
    except:
        print("""The login credentials you entered are not valid for
            the database you indicated.  Please check your login details and try
            again.""")
    return mydb

#Converting Genre column into unique values
def explode(df, lst_cols, fill_value=''):
    # make sure `lst_cols` is a list
    if lst_cols and not isinstance(lst_cols, list):
        lst_cols = [lst_cols]
    # all columns except `lst_cols`
    idx_cols = df.columns.difference(lst_cols)

    # calculate lengths of lists
    lens = df[lst_cols[0]].str.len()

    if (lens > 0).all():
        # ALL lists in cells aren't empty
        return pd.DataFrame({
            col: np.repeat(df[col].values, lens)
            for col in idx_cols
        }).assign(**{col: np.concatenate(df[col].values) for col in lst_cols}) \
          .loc[:, df.columns]
    else:
        # at least one list in cells is empty
        return pd.DataFrame({
            col: np.repeat(df[col].values, lens)
            for col in idx_cols
        }).assign(**{col: np.concatenate(df[col].values) for col in lst_cols}) \
          .append(df.loc[lens == 0, idx_cols]).fillna(fill_value) \
          .loc[:, df.columns]


# Basic Data for each Page
mydb=DatabaseConnection('root','Data@123','imdbmovies')
cursor = connection.cursor()
count = movies.objects.all().count()
#genre = movies.objects.filter(critic_rating>6).count()
cursor.execute("select count(distinct genre) from first_app_movies;")
#genre =cursor.fetchone()[0]
cursor.execute("select count(*) from first_app_movies where critic_rating>=4;")
liked =cursor.fetchone()[0]
cursor.execute("select count(*) from first_app_movies where critic_rating<=2;")
disliked =cursor.fetchone()[0]
movie=pd.read_sql("""select title,genre,year,audience_rating,critic_rating,budget_in_millions
                    from first_app_movies
                    where url!='N/A' and
                    genre!='N/A'and
                    year!=0 and
                    Audience_rating!=0 and
                    critic_rating!=0 and
                    budget_In_millions!=0 and
                    user_review <> '';""",mydb)

movie.genre = movie.genre.str.split(',')
movie = explode(movie,['genre'])
movie.genre=movie.genre.str.strip(' ')
movie.genre=movie.genre.astype('category')
genre=len(movie.genre.cat.categories)
movie.audience_rating=movie.audience_rating*10
movie.critic_rating=movie.critic_rating*10
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
file_loc=os.path.join(os.path.join(BASE_DIR,"static"),"images")
context={
    'Total': count,
    'Genre': genre,
    'Liked': liked,
    'Disliked': disliked
    #'output' : response
}
# Getting movie Data from API
def getMovieData(Movietitle):
    try:
        url = "http://www.omdbapi.com/?t={}&apikey=5ddb11dd".format(Movietitle)
        #print("Retrieving the data of \"{}\" now…".format(Movietitle))
        api_request = requests.get(url)
        source = json.loads(api_request.content)
    except requests.RequestException as e:
        print(f"ERROR: {e.reason}")
    return source

# Getting User Reviews and Budget by Web Scrapping
def Extract_Budget_UserReview(imdbID):
    c = CurrencyConverter()
    CurrencyDict = {'$': 'USD', '£': 'GBP', '¥': 'JPY', '€': 'EUR', '₹': 'INR'}
    url = 'http://www.imdb.com/title/{}/?ref_=fn_al_nm_1a'.format(imdbID)
    data = requests.get(url)
    soup = BeautifulSoup(data.text, 'html.parser')
    Budget = 0
    userReview = ""

    #Extracting the user Review of the movie
    movie = soup.findAll('div', {'class': 'user-comments'})
    for res in movie:
        userReview = res.span.strong.text
        if userReview is None:
            userReview='N/A'

    #Extracting the Budget of the movie
    for h4 in soup.find_all('h4'):
        if "Budget:" in h4:
            Budget = h4.next_sibling
            match = re.search(r'([\D]+)([\d,]+)', Budget)
            output = (match.group(1).replace('\xa0', ''),
                      match.group(2).replace(',', ''))
            if len(output[0]) == 1:
                Budget = round(
                    (c.convert(output[1], CurrencyDict[output[0]], 'USD')/1000000), 2)
            elif len(output[0]) == 3 and output[0] == 'XAF':
                Budget = round((float(output[1])*0.00174637)/1000000, 2)
            elif len(output[0]) == 3 and output[0] == 'FRF':
                Budget = round((float(output[1])*0.17)/1000000, 2)
            elif len(output[0]) == 3 and output[0] == 'IRR':
                Budget = round((float(output[1])*0.0000237954)/1000000, 2)
            elif len(output[0]) == 3 and output[0] == 'PKR':
                Budget = round((float(output[1])*0.007225614)/1000000, 2)
            elif len(output[0]) == 3 and output[0] == 'NPR':
                Budget = round((float(output[1])*87.0521)/1000000, 2)
            elif len(output[0]) == 3 and output[0] != 'FRF':
                Budget = round(
                    c.convert(output[1], output[0], 'USD')/1000000, 2)
    return Budget,userReview


def index(request):
    #cursor = connection.cursor()
    #cursor.execute("select count(*) from first_app_movies;")
    df=pd.read_sql("select Genre from first_app_movies order by Audience_Rating desc limit 5;",mydb)
    df.Genre = df.Genre.str.split(',')
    df = explode(df,['Genre'])
    list2=[df]
###   use this directly
    #df.Genre=df.Genre.str.strip(' ')
    #df.Genre=df.Genre.astype('category')
    #df.Genre.cat.categories


    #BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    #file_loc=os.path.join(os.path.join(BASE_DIR,"static"),"images")
    #file_loc = file_loc+'\\pie.png'
    #df.Genre.value_counts().plot(kind='pie')
    ##code for top 10 images

    #getting urls of top 10 movies
    df=pd.read_sql("select url,Audience_Rating from first_app_movies order by Audience_Rating desc limit 10;",mydb)
    df=df.drop(["Audience_Rating"],axis=1)


    # Adding data to context
    context={
        'Total': count,
        'Genre': genre,
        'Liked': liked,
        'Disliked': disliked,
        'Url1': df.iloc[0][0],
        'Url2': df.iloc[1][0],
        'Url3': df.iloc[2][0],
        'Url4': df.iloc[3][0],
        'Url5': df.iloc[4][0],
        'Url6': df.iloc[5][0],
        'Url7': df.iloc[6][0],
        'Url8': df.iloc[7][0],
        'Url9': df.iloc[8][0],
        'Url10':df.iloc[9][0]
        #'output' : response
    }


    return render(request,'first_app/index.html',context)

def search(request):
    cursor = connection.cursor()
    #mydb=DatabaseConnection('root','Data@123','imdbmovies')
    if request.method == 'POST':
        search_text = request.POST['searchField']    #user input from searchField
        if search_text == "":                       #if its blank
            return render(request,'first_app/search_result_fail.html')
        else:
            try:
                cursor.execute("""select title,genre,year,audience_rating,critic_rating,url,budget_in_millions,user_review,polarity from first_app_movies where title like %s limit 1""",("%" + search_text + "%",))
                result=cursor.fetchall()
                if not result:
                    result_new=getMovieData(search_text) #if not present in DB getting information from API
                    if result_new['Response']!='False':
                        budget,User_Review = Extract_Budget_UserReview(result_new['imdbID'])
                        context_search={
                        'Title': result_new['Title'],
                        'Year': result_new['Released'],
                        'url':result_new['Poster'],
                        'Genre': result_new['Genre'],
                        'aud_rating': result_new['imdbRating'],
                        'critic_rating':result_new['Metascore'],
                        'budget':budget,
                        'user_review':User_Review
                        }
                        return render(request,'first_app/search_result.html',context_search)
                    else:
                        return render(request,'first_app/search_result_fail.html')
                else:
                    if result[0][8]=="Negative":
                        sentiment="https://cdn1.iconfinder.com/data/icons/hawcons/32/699721-icon-5-neutral-face-512.png"
                    else:
                        sentiment="https://cdn1.iconfinder.com/data/icons/hawcons/32/699734-icon-6-smiling-face-512.png"

                    context_search={
                        'Title': result[0][0],
                        'Year': result[0][2],
                        'url': result[0][5],
                        'Genre':result[0][1],
                        'aud_rating':round(result[0][3],1),
                        'critic_rating':round(result[0][4],1),
                        'budget':round(result[0][6]),
                        'user_review':result[0][7],
                        'sentiment':sentiment
                        }
                    return render(request,'first_app/search_result.html',context_search)
            except:
                return render(request,'first_app/search_result_fail.html')
    else:
        return render(request,'first_app/search.html')

def top_rated(request):
    #plotting graph
    p=sns.factorplot(aspect=1.5,y='title',x='audience_rating',data=movie.sort_values(['audience_rating','critic_rating'],ascending=False).drop(['genre'],axis=1).drop_duplicates().head(10),palette="ch:.25",kind='bar')
    p.set(xlim=(10,100))
    sns.set_style("ticks",{"xtick.major.size":8,"ytick.major.size":8})
    plt.title('Top 10 Rated Movies',fontsize=10)
    plt.ylabel('Title',fontsize=7)
    plt.xlabel('Audience Rating',fontsize=7)
    sns.despine(trim=True,left=True)

    #saving Local
    file_loc_new = file_loc+'\\top_rated.png'
    plt.savefig(file_loc_new,format="png")

    #setting basic context
    return render(request,'first_app/top_rated.html',context)

def top_buget(request):
    #plotting graph
    sns.factorplot(aspect=1.5,y='title',x='budget_in_millions',data=movie.sort_values(['budget_in_millions'],ascending=False).drop(['genre'],axis=1).drop_duplicates().head(10),palette="ch:.25",kind='bar')
    sns.set_style("ticks",{"xtick.major.size":8,"ytick.major.size":8})
    plt.title('Top 10 High Budget Movies',fontsize=10)
    plt.ylabel('Title',fontsize=7)
    plt.xlabel('Budget In Millions',fontsize=7)
    sns.despine(trim=True,left=True)
    #saving Local
    file_loc_new = file_loc+'\\top_budget.png'
    plt.savefig(file_loc_new,format="png")

    return render(request,'first_app/top_budget.html',context)

def histogram_critic(request):

    #plotting graph
    column='critic rating'.title()
    LabelDictCol = {'Critic Rating':'critic_rating','Audience Rating':'audience_rating','Budget In Millions':'budget_in_millions'}
    sns.set(style = 'whitegrid')
    fig,ax=plt.subplots()
    fig.set_size_inches(11.7,8.27)
    plt.hist(movie[LabelDictCol[column]],bins=30,color='slateblue')
    plt.title("{} Distribution".format(column),fontsize=20)
    plt.ylabel("Frequency",fontsize=15)
    plt.xlabel("{}".format(column),fontsize=15)
    file_loc_new = file_loc+'\\histogram_critic.png'
    #saving file local
    fig.savefig(file_loc_new,format="png")

    return render(request,'first_app/histogram_critic.html',context)

def aud_vs_critic(request):
    #plotting graph
    sns.set(style='whitegrid')
    j = sns.JointGrid(data=movie,x='critic_rating',y='audience_rating')
    j = j.plot_joint(plt.scatter,color="b", s=40, edgecolor="black",alpha=0.9)
    j = j.plot_marginals(sns.distplot, kde=False,color='blue')
    j = j.annotate(stats.pearsonr,loc="upper left")
    j.set_axis_labels('Critic Ratings','Audience Rating')
    file_loc_new = file_loc+'\\sb_graph1.png'
    j.savefig(file_loc_new,format="png")


    return render(request,'first_app/aud_vs_critic.html',context)

def histogram(request):

    column='audience rating'.title()
    LabelDictCol = {'Critic Rating':'critic_rating','Audience Rating':'audience_rating','Budget In Millions':'budget_in_millions'}
    sns.set(style = 'whitegrid')
    fig,ax=plt.subplots()
    fig.set_size_inches(11.7,8.27)
    plt.hist(movie[LabelDictCol[column]],bins=30,color='slateblue')
    plt.title("{} Distribution".format(column),fontsize=20)
    plt.ylabel("Frequency",fontsize=15)
    plt.xlabel("{}".format(column),fontsize=15)
    file_loc_new = file_loc+'\\histogram.png'
    fig.savefig(file_loc_new,format="png")
    return render(request,'first_app/histogram.html',context)

def budget(request):

    list1=[]
    GenreLabels=[]
    for gen in movie.genre.cat.categories:
        list1.append(movie[movie.genre==gen].budget_in_millions)
        GenreLabels.append(gen)
        sns.set(style='whitegrid')
    fig,ax=plt.subplots()
    fig.set_size_inches(11.7,8.27)
    plt.hist(list1,bins=30,stacked=True,rwidth=1,label=GenreLabels)
    plt.title("Movie Budget Distribution",fontsize=20)
    plt.ylabel("Number of Movies",fontsize=15)
    plt.xlabel("Budget$$$",fontsize=15)
    plt.legend(frameon=True,fancybox=True,prop={'size':10},framealpha=1)
    file_loc_new = file_loc+'\\budget.png'
    plt.savefig(file_loc_new,format="png")
    return render(request,'first_app/budget.html',context)

def aud_vs_critic_kde(request):
    #plotting graph
    g = sns.jointplot(x="critic_rating", y="audience_rating", data=movie, kind="kde", color="m")
    g.plot_joint(plt.scatter, c="w", s=30, linewidth=1, marker="+")
    g.ax_joint.collections[0].set_alpha(0.5)
    g.set_axis_labels("Critic Rating", "Audience Rating");
    file_loc_new = file_loc+'\\kde.png'
    g.savefig(file_loc_new,format="png")
    return render(request,'first_app/aud_vs_critic_kde.html',context)

def critic_skewness(request):
    #plotting graph
    fig,axes = plt.subplots(1,2,figsize=(12,6),sharex=True,sharey=True)
    KA=sns.kdeplot(movie.budget_in_millions,movie.audience_rating,ax=axes[0],shade=True,shade_lowest=False,cmap='Greens')
    KC=sns.kdeplot(movie.budget_in_millions,movie.critic_rating,ax=axes[1],shade=True,shade_lowest=False,cmap='Reds')
    file_loc_new = file_loc+'\\skew.png'
    fig.savefig(file_loc_new,format="png")
    return render(request,'first_app/critic_skewness.html',context)

def aud_boxplot(request):
    #plotting graph

    column1='genre'.title()
    column2='audience rating'.title()
    LabelDictCol = {'Critic Rating':'critic_rating','Audience Rating':'audience_rating','Budget':'budget_in_millions','Genre':'genre','Year':'year'}
    fig,ax=plt.subplots()
    sns.boxplot(data=movie,x=LabelDictCol[column1],y=LabelDictCol[column2],palette='Blues',whis="range")
    ax.yaxis.grid(True)
    ax.xaxis.grid(True)
    #plt.title('{} Vs {} Boxplot'.format(column1,column2),fontsize=12)
    plt.xlabel('{}'.format(column1),fontsize=7)
    plt.ylabel('{}'.format(column2),fontsize=7)
    plt.xticks(rotation=50)
    sns.despine(trim=True, left=True)

    file_loc_new = file_loc+'\\aud_box.png'
    fig.savefig(file_loc_new,format="png")

    return render(request,'first_app/aud_boxplot.html',context)

def critic_boxplot(request):
    #plotting graph

    column1='genre'.title()
    column2='critic rating'.title()
    LabelDictCol = {'Critic Rating':'critic_rating','Audience Rating':'audience_rating','Budget':'budget_in_millions','Genre':'genre','Year':'year'}
    fig,ax=plt.subplots()
    sns.boxplot(data=movie,y=LabelDictCol[column1],x=LabelDictCol[column2],palette='Blues',whis="range")
    ax.yaxis.grid(True)
    ax.xaxis.grid(True)
    #plt.title('{} Vs {} Boxplot'.format(column1,column2),fontsize=12)
    plt.xlabel('{}'.format(column1),fontsize=7)
    plt.ylabel('{}'.format(column2),fontsize=7)
    plt.xticks(rotation=50)
    sns.despine(trim=True, left=True)
    file_loc_new = file_loc+'\\critic_box.png'
    fig.savefig(file_loc_new,format="png")

    return render(request,'first_app/critic_boxplot.html',context)

def genre_barplot(request):
    #plotting graph

    column='genre'.title()
    LabelDictCol = {'Critic Rating':'critic_rating','Audience Rating':'audience_rating','Budget In Millions':'budget_in_millions','Genre':'genre','Year':'year'}
    sns.catplot(y=LabelDictCol[column], kind="count", palette="ch:.25", data=movie)
    plt.title('Barplot For {}'.format(column.capitalize()),fontsize=10)
    plt.ylabel('{}'.format(column.capitalize()),fontsize=7)
    plt.xlabel('')

    file_loc_new = file_loc+'\\genre_barplot.png'
    plt.savefig(file_loc_new,format="png")
    return render(request,'first_app/genre_barplot.html',context)

def year_barplot(request):

    #plotting graph

    column='year'.title()
    LabelDictCol = {'Critic Rating':'critic_rating','Audience Rating':'audience_rating','Budget In Millions':'budget_in_millions','Genre':'genre','Year':'year'}
    sns.catplot(y=LabelDictCol[column], kind="count", palette="ch:.25", data=movie)
    plt.title('Barplot For {}'.format(column.capitalize()),fontsize=10)
    plt.ylabel('{}'.format(column.capitalize()),fontsize=7)
    plt.xlabel('')


    file_loc_new = file_loc+'\\year_barplot.png'
    plt.savefig(file_loc_new,format="png")


    return render(request,'first_app/year_barplot.html',context)
