from django import Forms
from first_app.models import movies
class HomeForm(forms.ModelForm):
    post=forms.CharFiled()

    class Meta:
        model =movies
        fields = ('post',)
