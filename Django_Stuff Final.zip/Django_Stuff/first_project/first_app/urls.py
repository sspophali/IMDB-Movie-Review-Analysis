from django.urls import re_path
from first_app import views

urlpatterns=[
    re_path(r'^$',views.index,name='index'),
    re_path(r'^search_result/$',views.search,name='search'),
    re_path(r'^search_result_fail/$',views.search,name='search'),
    re_path(r'^search/$',views.search,name='search'),
    re_path(r'^aud_vs_critic/$',views.aud_vs_critic,name='aud_vs_critic'),
    re_path(r'^histogram/$',views.histogram,name='histogram'),
    re_path(r'^budget/$',views.budget,name='budget'),
    re_path(r'^aud_vs_critic_kde/$',views.aud_vs_critic_kde,name='aud_vs_critic_kde'),
    re_path(r'^critic_skewness/$',views.critic_skewness,name='critic_skewness'),
    re_path(r'^critic_boxplot/$',views.critic_boxplot,name='critic_boxplot'),
    re_path(r'^top_rated/$',views.top_rated,name='top_rated'),
    re_path(r'^top_budget/$',views.top_buget,name='top_budget'),
    re_path(r'^histogram_critic/$',views.histogram_critic,name='histogram_critic'),
    re_path(r'^aud_boxplot/$',views.aud_boxplot,name='aud_boxplot'),
    re_path(r'^genre_barplot/$',views.genre_barplot,name='genre_barplot'),
    re_path(r'^year_barplot/$',views.year_barplot,name='year_barplot')

]
