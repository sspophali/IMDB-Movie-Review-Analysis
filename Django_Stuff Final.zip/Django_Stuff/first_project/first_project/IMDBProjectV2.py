# -*- coding: utf-8 -*-
"""Created on Thu Jan 24 13:50:03 2019
@author: shaz-
"""
#########################################################################################################################
# Importing Packages
#########################################################################################################################

'''
Importing The Necessary Packages
'''
import json
import re
import requests
import warnings
import numpy as np
import pandas as pd
import mysql.connector
import urllib.request
from scipy import stats
import seaborn as sns
from bs4 import BeautifulSoup
from currency_converter import CurrencyConverter
from matplotlib import pyplot as plt
warnings.filterwarnings('ignore')
sns.set(style="darkgrid", color_codes=True)

#########################################################################################################################
# Defining Functions
#########################################################################################################################

'''Budget and Review need to be extracted from IMDB website '''
def Extract_Budget_UserReview(imdbID):
    c = CurrencyConverter()
    CurrencyDict = {'$': 'USD', '£': 'GBP', '¥': 'JPY', '€': 'EUR', '₹': 'INR'}
    url = 'http://www.imdb.com/title/{}/?ref_=fn_al_nm_1a'.format(imdbID)
    data = requests.get(url)
    soup = BeautifulSoup(data.text, 'html.parser')
    Budget = 0
    userReview = ""
    
    #Extracting the user Review of the movie
    movie = soup.findAll('div', {'class': 'user-comments'})
    for res in movie:
        userReview = res.span.strong.text
        if userReview is None:
            userReview='N/A'
        
    #Extracting the Budget of the movie
    for h4 in soup.find_all('h4'):
        if "Budget:" in h4:
            Budget = h4.next_sibling
            match = re.search(r'([\D]+)([\d,]+)', Budget)
            output = (match.group(1).replace('\xa0', ''),
                      match.group(2).replace(',', ''))
            if len(output[0]) == 1:
                Budget = round(
                    (c.convert(output[1], CurrencyDict[output[0]], 'USD')/1000000), 2)
            elif len(output[0]) == 3 and output[0] == 'XAF':
                Budget = round((float(output[1])*0.00174637)/1000000, 2)
            elif len(output[0]) == 3 and output[0] == 'FRF':
                Budget = round((float(output[1])*0.17)/1000000, 2)
            elif len(output[0]) == 3 and output[0] == 'IRR':
                Budget = round((float(output[1])*0.0000237954)/1000000, 2)
            elif len(output[0]) == 3 and output[0] == 'PKR':
                Budget = round((float(output[1])*0.007225614)/1000000, 2)
            elif len(output[0]) == 3 and output[0] == 'NPR':
                Budget = round((float(output[1])*87.0521)/1000000, 2)
            elif len(output[0]) == 3 and output[0] != 'FRF':
                Budget = round(
                    c.convert(output[1], output[0], 'USD')/1000000, 2)
    return Budget,userReview

'''Extracting movie details from API'''
def getMovieData(Movietitle):
    try:
        url = "http://www.omdbapi.com/?t={}&apikey=5ddb11dd".format(Movietitle)
        print("Retrieving the data of \"{}\" now…".format(Movietitle))
        api_request = requests.get(url)
        source = json.loads(api_request.content)
    except requests.RequestException as e:
        print(f"ERROR: {e.reason}")
    return source

'''Establishing Database Connection'''
def DatabaseConnection(user, passwd, database):
    try:
        mydb = mysql.connector.connect(host='localhost',
                                       user=user,
                                       passwd=passwd,
                                       db=database,
                                        database=database,auth_plugin='mysql_native_password')
    except:
        print("""The login credentials you entered are not valid for
            the database you indicated.  Please check your login details and try
            again.""")        
    return mydb


'''This function will sepearte each word from genre and stack it in long format'''
def explode(df, lst_cols, fill_value=''):
    # make sure `lst_cols` is a list
    if lst_cols and not isinstance(lst_cols, list):
        lst_cols = [lst_cols]
    # all columns except `lst_cols`
    idx_cols = df.columns.difference(lst_cols)

    # calculate lengths of lists
    lens = df[lst_cols[0]].str.len()

    if (lens > 0).all():
        # ALL lists in cells aren't empty
        return pd.DataFrame({
            col: np.repeat(df[col].values, lens)
            for col in idx_cols
        }).assign(**{col: np.concatenate(df[col].values) for col in lst_cols}) \
          .loc[:, df.columns]
    else:
        # at least one list in cells is empty
        return pd.DataFrame({
            col: np.repeat(df[col].values, lens)
            for col in idx_cols
        }).assign(**{col: np.concatenate(df[col].values) for col in lst_cols}) \
          .append(df.loc[lens == 0, idx_cols]).fillna(fill_value) \
          .loc[:, df.columns]

'''This Function will put the data extracted from API and from webscraping into movie database '''

def DataIntoDatabase(MovieData, mydb, mycursor):
    budget,User_Review = Extract_Budget_UserReview(MovieData['imdbID'])
    if MovieData['Metascore'] == 'N/A':
       metascore = 0
    else:
       metascore = (float((MovieData['Metascore']))/10)
                
    if MovieData['imdbRating']=='N/A':
       imdb_rating=0
    else:
       imdb_rating = float(MovieData['imdbRating'])

    if MovieData['Released']=='N/A':
       release_year=0
    else:
       release_year=int(MovieData['Released'].split(' ')[2])
        
    if MovieData['Poster']=="N/A":
       image_url='Image Not Available'
    else:
       image_url=MovieData['Poster']
        
    sql = """INSERT INTO movies(IMDBID, Title, Genre, Year, URL, Audience_Rating, Critic_Rating, Budget_In_Millions, User_Review) 
                VALUES (%s, %s,%s, %s,%s,%s,%s,%s,%s)
                ON DUPLICATE KEY UPDATE 
                Audience_Rating=values(Audience_Rating),
                Critic_Rating=values(Critic_Rating),
                Budget_In_Millions=values(Budget_In_Millions),
                User_Review=values(User_Review);"""

    val=[(MovieData['imdbID'],MovieData['Title'],
        MovieData['Genre'],release_year,image_url,
        imdb_rating,metascore,budget,User_Review)] 
    mycursor.executemany(sql, val)
    mydb.commit()

'''This function will fetch the data from database from the title provided by the user'''

def getDataFromDatabase(UserInputTitle):       
    mydb=DatabaseConnection('root','$shaz$786','IMDBMovies')
    mycursor=mydb.cursor()  
    mycursor.execute("""select title,genre,year,audience_rating,critic_rating 
                     from movies where title like %s limit 1""",("%" + UserInputTitle + "%",))
    myresult = mycursor.fetchall()
    return myresult

'''
This is use to display info about the movie title provided by the user, 
at the same time if the movie title doesn't exist the it will make an entry into the database 
and then it will fetch the data from database to display info. 
'''

def DisplayMovieInfo(UserInputTitle):   
    mydb=DatabaseConnection('root','Data@123','IMDBMovies')
    cursor=mydb.cursor()
    myresult=getDataFromDatabase(UserInputTitle)
    if not myresult:
        MovieData=getMovieData(UserInputTitle)
        if MovieData['Response']=='False':
           print("Sorry!!! The Movie Doesn't Exist.....:(")
        else:
           DataIntoDatabase(MovieData,mydb,mycursor)           
           myresult=getDataFromDatabase(UserInputTitle)
           print("Title: {}".format(myresult[0][0]))
           print("Genre: {}".format(myresult[0][1]))
           print("Year: {}".format(myresult[0][2]))
           print("Audience Rating: {}".format(myresult[0][3]))
           print("Critic Rating: {}".format(myresult[0][4]))
    else:
        print("Title: {}".format(myresult[0][0]))
        print("Genre: {}".format(myresult[0][1]))
        print("Year: {}".format(myresult[0][2]))
        print("Audience Rating: {}".format(myresult[0][3]))
        print("Critic Rating: {}".format(myresult[0][4]))

'''
This Function will fetch the data by year
'''
def getDataByYear(FirstRange,SecondRange):       
    movieData=pd.read_sql("""select title,genre,year,audience_rating,critic_rating,budget_in_millions 
                                from movies 
                                where url!='N/A' and 
                                genre!='N/A'and 
                                year!=0 and 
                                Audience_rating!=0 and 
                                critic_rating!=0 and 
                                budget_in_millions!=0 and 
                                user_review <> '' and Year BETWEEN {} and {};""".format(FirstRange,SecondRange),DatabaseConnection('root','$shaz$786','imdbmovies'))
    return movieData

#########################################################################################################################
# The Main Part for Displaying Movie info to the user
#########################################################################################################################

try:
    UserInputTitle=input("Please Enter The Title of the Movie:\n")
    if UserInputTitle=='':
        print("No Input Provided")
    else:
        DisplayMovieInfo(UserInputTitle)
except:
    print("Some Error Occured.....Please Check The Input Provided")
    

#########################################################################################################################
# Performing EDA on Data Collected from IMDB
#########################################################################################################################

year=pd.read_sql('select max(year) as Max_Year, min(year) as Min_Year from movies',DatabaseConnection('root','$shaz$786','imdbmovies'))
print("So We've Data from {} to {}.\n Tell range so as to bring you the analysis".format(year.Min_Year[0],year.Max_Year[0]))
try:
    FirstRange=int(input("Please Enter The Range 1:\n"))
    SecondRange=int(input("Please Enter The Range 2:\n"))
    if FirstRange=='' and SecondRange=='':
        print("No input was provided")
    elif FirstRange > SecondRange:
        print('Provided range is invlid...since First range cannot be greater than the Second')
    else:
        movieData=getDataByYear(FirstRange,SecondRange)
        print(movieData)    
except:
    print("Please provide correct input...since the entered value is not a number.")    


movie=pd.read_sql("""select title,genre,year,audience_rating,critic_rating,budget_in_millions 
                        from movies 
                        where url!='N/A' and 
                        genre!='N/A'and 
                        year!=0 and 
                        Audience_rating!=0 and 
                        critic_rating!=0 and 
                        budget_in_millions!=0 and 
                        user_review <> '';""",DatabaseConnection('root','$shaz$786','imdbmovies'))

movie.head()
movie.info()
movie.describe()

movie.genre = movie.genre.str.split(',')
movie = explode(movie,['genre']) 
movie.genre=movie.genre.str.strip(' ')
movie.genre=movie.genre.astype('category')
movie.genre.cat.categories

#movie.title=movie.title.astype('category')
movie.audience_rating=movie.audience_rating*10
movie.critic_rating=movie.critic_rating*10



def DisplayCricticAudienceRating():
    #Joint Plot Critic Rating Vs Audience Rating
    sns.set(style='whitegrid')
    j = sns.JointGrid(data=movie,x='critic_rating',y='audience_rating')
    j = j.plot_joint(plt.scatter,color="g", s=40, edgecolor="black")
    j = j.plot_marginals(sns.distplot, kde=False,)
    j = j.annotate(stats.pearsonr,loc="upper left")
    j.set_axis_labels('Critic Ratings','Audience Rating')

DisplayCricticAudienceRating()


# Histogram
def DiplayHistogram(column):
    column=column.title()
    LabelDictCol = {'Critic Rating':'critic_rating','Audience Rating':'audience_rating','Budget In Millions':'budget_in_millions'}        
    sns.set(style = 'whitegrid')
    #sns.palplot(sns.cubehelix_palette(8,start=.5,rot=-0.75))
    fig,ax=plt.subplots()
    fig.set_size_inches(11.7,8.27)
    plt.hist(movie[LabelDictCol[column]],bins=30,color=)
    plt.title("{} Distribution".format(column),fontsize=20)
    plt.ylabel("Frequency",fontsize=15)
    plt.xlabel("{}".format(column),fontsize=15)    
    fig.savefig('hist1.png')
    
DiplayHistogram('audience rating')

# Stack distribution
def DisplayStackedHistogram(movie):
    list1=[]
    GenreLabels=[]
    for gen in movie.genre.cat.categories:
        list1.append(movie[movie.genre==gen].budget)
        GenreLabels.append(gen)
        sns.set(style='whitegrid')        
    fig,ax=plt.subplots()
    fig.set_size_inches(11.7,8.27)
    plt.hist(list1,bins=30,stacked=True,rwidth=1,label=GenreLabels)
    plt.title("Movie Budget Distribution",fontsize=20)
    plt.ylabel("Number of Movies",fontsize=15)
    plt.xlabel("Budget$$$",fontsize=15)
    plt.legend(frameon=True,fancybox=True,prop={'size':10},framealpha=1)
    plt.show()

DisplayStackedHistogram(movie)


# Creating KDE i.e kernel density estimate plot
# Scatter plot
def CriticVsAudience():
    sns.lmplot(data=movie,x='critic_rating',y='audience_rating',fit_reg=False,hue='genre',size=7,aspect=1,legend=False)
    plt.title("Critic Rating Vs Audience Rating",fontsize=20)
    plt.ylabel("Audience Rating",fontsize=15)
    plt.xlabel("Critic Rating",fontsize=15)
    plt.legend(frameon=True,fancybox=True,prop={'size':10},framealpha=1)
    plt.show()

CriticVsAudience()

# KDE its awesome!!!
def CriticVsAudienceKDE():
    g = sns.jointplot(x="critic_rating", y="audience_rating", data=movie, kind="kde", color="m")
    g.plot_joint(plt.scatter, c="w", s=30, linewidth=1, marker="+")
    g.ax_joint.collections[0].set_alpha(0.5)
    g.set_axis_labels("Critic Rating", "Audience Rating");

CriticVsAudienceKDE()

# Subplot
# It indicate us whether the budget of the movie affect rating that audience gave,
# is there any skew of visualization 
fig,axes = plt.subplots(1,2,figsize=(12,6),sharex=True,sharey=True)
KA=sns.kdeplot(movie.budget,movie.audience_rating,ax=axes[0],shade=True,shade_lowest=False,cmap='Greens')
KC=sns.kdeplot(movie.budget,movie.critic_rating,ax=axes[1],shade=True,shade_lowest=False,cmap='Reds')


# how crtic rating is dtributted accross different genre
def DisplayBoxplot(data,column1,column2): 
    column1=column1.title()
    column2=column2.title()
    LabelDictCol = {'Critic Rating':'critic_rating','Audience Rating':'audience_rating','Budget In Millions':'budget_in_millions','Genre':'genre','Year':'year'}        
    fig,ax=plt.subplots()  
    sns.boxplot(data=data,x=LabelDictCol[column1],y=LabelDictCol[column2],palette='Blues',whis="range")
    ax.yaxis.grid(True)
    ax.xaxis.grid(True)
    plt.title('{} Vs {} Boxplot'.format(column1,column2),fontsize=20)
    plt.xlabel('{}'.format(column1),fontsize=15)
    plt.ylabel('{}'.format(column2),fontsize=15)
    plt.xticks(rotation=30)
    sns.despine(trim=True, left=True)

DisplayBoxplot(movie,'year','critic rating')

#Diplay top 10 Rated movies
def catPlot(data,column):
    column=column.title()
    LabelDictCol = {'Critic Rating':'critic_rating','Audience Rating':'audience_rating','Budget In Millions':'budget_in_millions','Genre':'genre','Year':'year'}        
    sns.catplot(y=LabelDictCol[column], kind="count", palette="ch:.25", data=data)
    plt.title('Barplot For {}'.format(column.capitalize()),fontsize=20)
    plt.ylabel('{}'.format(column.capitalize()),fontsize=15)
    plt.xlabel('')    
catPlot(movie,'year')

def getTop10(data):
    p=sns.factorplot(aspect=1.5,y='title',x='audience_rating',data=data.sort_values(['audience_rating','critic_rating'],ascending=False).drop(['genre'],axis=1).drop_duplicates().head(10),palette="ch:.25",kind='bar')
    p.set(xlim=(10,100))
    sns.set_style("ticks",{"xtick.major.size":8,"ytick.major.size":8})
    plt.title('Top 10 Rated Movies')
    plt.xlabel('Title')
    plt.ylabel('Audience Rating')
    plt.legend(frameon=True,fancybox=True,prop={'size':10},framealpha=1)
#    plt.xticks(rotation=25)
    sns.despine(trim=True,left=True)

getTop10(movie)

